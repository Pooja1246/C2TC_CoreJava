/**
 * 
 */
/**
 * @author ADMIN
 *
 */
module Amazon {
}