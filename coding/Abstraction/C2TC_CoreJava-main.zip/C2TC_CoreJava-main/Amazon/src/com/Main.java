package com;

abstract class Main {
	//Abstraction for the Application Amozan
	abstract void account();
	

	}
