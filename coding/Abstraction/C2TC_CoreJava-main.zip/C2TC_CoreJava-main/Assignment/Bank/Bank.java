public abstract class Bank {
    abstract void getinterest();
}