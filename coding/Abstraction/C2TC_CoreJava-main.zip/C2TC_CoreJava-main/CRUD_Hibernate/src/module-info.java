/**
 * 
 */
/**
 * @author ADMIN
 *
 */
module CRUD_Hibernate {
}