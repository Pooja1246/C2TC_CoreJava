package com.Entity;

public class Client {

}
