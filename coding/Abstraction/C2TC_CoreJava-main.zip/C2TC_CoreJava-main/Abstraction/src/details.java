public class details {
    public static void main(String[] args) {
        USers use= new USers();
        Banks b= new Banks();

//calling the implementation methods
b.bank();
        use.Userdetails();
        use.Withdraw();
        use.Deposit();



    }






}
