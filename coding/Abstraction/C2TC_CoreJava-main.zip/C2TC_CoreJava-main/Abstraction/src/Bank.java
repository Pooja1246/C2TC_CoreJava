abstract class Bank {

    abstract void Withdraw();

    abstract void Deposit();

    abstract void Userdetails();

}

